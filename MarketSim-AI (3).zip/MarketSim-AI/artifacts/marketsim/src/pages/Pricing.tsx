import { useEffect, useState } from "react";
import { Check, CreditCard, Loader2, Sparkles } from "lucide-react";
import { useLocation } from "wouter";

type Plan = {
  key: string;
  title: string;
  price: number;
  periodLabel: string;
  description: string;
};

const fallbackPlans: Plan[] = [
  { key: "monthly", title: "شهري", price: 50, periodLabel: "شهريًا", description: "للتجارب السريعة وإطلاق أفكار جديدة كل شهر" },
  { key: "quarterly", title: "3 أشهر", price: 100, periodLabel: "كل 3 أشهر", description: "أفضل قيمة لبناء قرارات متتالية" },
  { key: "semiannual", title: "6 أشهر", price: 250, periodLabel: "كل 6 أشهر", description: "للفرق والمشاريع التي تختبر السوق باستمرار" },
];

export default function Pricing() {
  const [, setLocation] = useLocation();
  const [plans, setPlans] = useState<Plan[]>(fallbackPlans);
  const [loadingPlan, setLoadingPlan] = useState<string | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch("/api/billing/plans", { credentials: "include" })
      .then((response) => (response.ok ? response.json() : null))
      .then((data) => {
        if (Array.isArray(data?.plans)) setPlans(data.plans);
      })
      .catch(() => {
        // The server catalog is mirrored in fallbackPlans for a resilient first render.
      });
  }, []);

  const startCheckout = async (planKey: string) => {
    setLoadingPlan(planKey);
    setError("");
    try {
      const response = await fetch("/api/billing/checkout", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ planKey }),
      });
      const data = await response.json();
      if (!response.ok || !data.purchaseUrl) {
        throw new Error(data.error || "تعذر تجهيز صفحة الدفع");
      }
      window.location.assign(data.purchaseUrl);
    } catch (checkoutError) {
      setError(
        checkoutError instanceof Error
          ? checkoutError.message
          : "تعذر تجهيز صفحة الدفع",
      );
      setLoadingPlan(null);
    }
  };

  return (
    <div className="container mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <div className="mx-auto mb-10 max-w-2xl text-center">
        <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-violet-400/20 bg-violet-400/10 px-4 py-2 text-xs font-black uppercase tracking-widest text-violet-300">
          <Sparkles className="h-4 w-4" />
          اختر خطتك
        </div>
        <h1 className="text-4xl font-black text-white sm:text-5xl">استمر في اختبار السوق</h1>
        <p className="mt-4 text-sm leading-7 text-white/50">
          ابدأ بثلاثة أيام مجانية وثلاث محاكاة، ثم اختر الخطة التي تناسب وتيرة عملك.
        </p>
      </div>

      {error ? (
        <div className="mx-auto mb-6 max-w-2xl rounded-xl border border-rose-400/20 bg-rose-500/10 p-4 text-center text-sm text-rose-200">
          {error}
        </div>
      ) : null}

      <div className="grid gap-5 md:grid-cols-3">
        {plans.map((plan, index) => (
          <article
            key={plan.key}
            className={`glass-panel relative flex flex-col p-6 ${
              index === 1 ? "border-violet-400/40 shadow-[0_0_35px_-12px_rgba(139,92,246,.65)]" : ""
            }`}
          >
            {index === 1 ? (
              <span className="absolute -top-3 right-6 rounded-full bg-gradient-to-l from-cyan-400 to-violet-500 px-3 py-1 text-[10px] font-black text-white">
                الأكثر اختيارًا
              </span>
            ) : null}
            <div className="mb-6 flex items-start justify-between">
              <div>
                <h2 className="text-2xl font-black text-white">{plan.title}</h2>
                <p className="mt-2 text-sm leading-6 text-white/45">{plan.description}</p>
              </div>
              <CreditCard className="h-6 w-6 text-cyan-300" />
            </div>
            <div className="mb-6">
              <span className="text-4xl font-black text-white">${plan.price}</span>
              <span className="mr-2 text-sm text-white/40">{plan.periodLabel}</span>
            </div>
            <ul className="mb-8 flex-1 space-y-3 text-sm text-white/65">
              {["محاكاة سوق كاملة", "حفظ سجل المحاكيات", "تقرير استراتيجي قابل للتنفيذ"].map((item) => (
                <li key={item} className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-emerald-400" />
                  {item}
                </li>
              ))}
            </ul>
            <button
              type="button"
              disabled={loadingPlan !== null}
              onClick={() => startCheckout(plan.key)}
              className="gradient-button flex w-full items-center justify-center gap-2 rounded-xl px-5 py-3 font-black"
            >
              {loadingPlan === plan.key ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              المتابعة للدفع الآمن
            </button>
          </article>
        ))}
      </div>

      <button
        type="button"
        onClick={() => setLocation("/account")}
        className="mx-auto mt-8 block text-sm font-bold text-white/45 transition-colors hover:text-white"
      >
        العودة إلى الحساب
      </button>
    </div>
  );
}