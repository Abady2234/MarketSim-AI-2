import { useEffect, useMemo, useState } from "react";
import {
  Activity,
  Ban,
  CheckCircle2,
  Clock3,
  DollarSign,
  Eye,
  LogOut,
  PauseCircle,
  PlayCircle,
  RefreshCw,
  Search,
  ShieldAlert,
  ShieldCheck,
  Users,
  XCircle,
} from "lucide-react";

type AdminUser = {
  id: number;
  clerkUserId: string;
  email: string | null;
  displayName: string | null;
  accessStatus: "active" | "suspended" | string;
  suspendedAt: string | null;
  suspensionReason: string | null;
  trialEndsAt: string;
  createdAt: string;
  simulationCount: number;
  usageCount: number;
  subscription: {
    id: number;
    planId: string;
    planTitle: string;
    planPrice: number | null;
    membershipId: string | null;
    status: string;
    currentPeriodEnd: string | null;
    cancelAtPeriodEnd: boolean;
  } | null;
};

type AdminOverview = {
  generatedAt: string;
  metrics: {
    totalUsers: number;
    activeSubscribers: number;
    trialUsers: number;
    suspendedUsers: number;
    totalSimulations: number;
    totalUsage: number;
    completedCheckouts: number;
    estimatedRevenue: number;
  };
  users: AdminUser[];
};

const dateFormatter = new Intl.DateTimeFormat("ar-SA", {
  dateStyle: "medium",
  timeStyle: "short",
});

function formatDate(value: string | null) {
  return value ? dateFormatter.format(new Date(value)) : "—";
}

function StatCard({
  icon: Icon,
  label,
  value,
  detail,
  tone,
}: {
  icon: typeof Users;
  label: string;
  value: string | number;
  detail: string;
  tone: string;
}) {
  return (
    <div className="glass-panel p-5">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-sm text-white/45">{label}</p>
          <p className="mt-2 text-3xl font-black text-white">{value}</p>
          <p className="mt-2 text-xs text-white/35">{detail}</p>
        </div>
        <div className={`rounded-2xl p-3 ${tone}`}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </div>
  );
}

export default function Admin() {
  const [overview, setOverview] = useState<AdminOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [busyAction, setBusyAction] = useState("");

  const loadOverview = async (quiet = false) => {
    if (quiet) setRefreshing(true);
    else setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/admin/overview", {
        credentials: "include",
        cache: "no-store",
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر تحميل لوحة الإدارة");
      setOverview(data);
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "تعذر تحميل لوحة الإدارة");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    void loadOverview();
  }, []);

  const filteredUsers = useMemo(() => {
    if (!overview) return [];
    const query = search.trim().toLowerCase();
    if (!query) return overview.users;
    return overview.users.filter((user) =>
      [user.displayName, user.email, user.clerkUserId, String(user.id)]
        .filter(Boolean)
        .some((value) => String(value).toLowerCase().includes(query)),
    );
  }, [overview, search]);

  const runAction = async (key: string, url: string, body?: object) => {
    setBusyAction(key);
    setError("");
    try {
      const response = await fetch(url, {
        method: "POST",
        credentials: "include",
        headers: body ? { "Content-Type": "application/json" } : undefined,
        body: body ? JSON.stringify(body) : undefined,
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر تنفيذ الإجراء");
      await loadOverview(true);
    } catch (actionError) {
      setError(actionError instanceof Error ? actionError.message : "تعذر تنفيذ الإجراء");
    } finally {
      setBusyAction("");
    }
  };

  const confirmAction = (message: string, key: string, url: string, body?: object) => {
    if (window.confirm(message)) void runAction(key, url, body);
  };

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center text-white/60">
        <RefreshCw className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  if (!overview) {
    return (
      <div className="container mx-auto max-w-2xl px-4 py-20 text-center">
        <ShieldAlert className="mx-auto h-12 w-12 text-rose-300" />
        <h1 className="mt-5 text-3xl font-black text-white">لا تملك صلاحية الإدارة</h1>
        <p className="mt-3 text-sm leading-7 text-white/50">{error || "هذه الصفحة خاصة بمدير التطبيق."}</p>
      </div>
    );
  }

  const { metrics } = overview;

  return (
    <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <div className="mb-8 flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
        <div>
          <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-cyan-400/20 bg-cyan-400/10 px-3 py-1.5 text-xs font-black text-cyan-200">
            <ShieldCheck className="h-4 w-4" />
            منطقة المدير
          </div>
          <h1 className="text-4xl font-black text-white sm:text-5xl">لوحة إدارة MarketSim</h1>
          <p className="mt-3 max-w-2xl text-sm leading-7 text-white/50">
            راقب المشتركين والاستخدام والمدفوعات وتحكم في الوصول من مكان واحد.
          </p>
        </div>
        <button
          type="button"
          onClick={() => void loadOverview(true)}
          disabled={refreshing}
          className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/[0.06] px-4 py-3 text-sm font-bold text-white/70 transition hover:bg-white/[0.1] hover:text-white disabled:opacity-50"
        >
          <RefreshCw className={`h-4 w-4 ${refreshing ? "animate-spin" : ""}`} />
          تحديث البيانات
        </button>
      </div>

      {error ? (
        <div className="mb-6 flex items-center gap-2 rounded-xl border border-rose-400/20 bg-rose-500/10 p-4 text-sm text-rose-100">
          <XCircle className="h-5 w-5 shrink-0" />
          {error}
        </div>
      ) : null}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard icon={Users} label="إجمالي المستخدمين" value={metrics.totalUsers} detail={`${metrics.trialUsers} في التجربة المجانية`} tone="bg-violet-500/15 text-violet-200" />
        <StatCard icon={CheckCircle2} label="المشتركون الفعالون" value={metrics.activeSubscribers} detail={`${metrics.completedCheckouts} عملية مكتملة`} tone="bg-emerald-500/15 text-emerald-200" />
        <StatCard icon={Activity} label="إجمالي المحاكيات" value={metrics.totalSimulations} detail={`${metrics.totalUsage} استخدامًا مسجلًا`} tone="bg-cyan-500/15 text-cyan-200" />
        <StatCard icon={DollarSign} label="الإيراد التقديري" value={`$${metrics.estimatedRevenue.toLocaleString("en-US")}`} detail={`${metrics.suspendedUsers} حساب موقوف`} tone="bg-amber-500/15 text-amber-200" />
      </div>

      <section className="mt-8 glass-panel overflow-hidden">
        <div className="flex flex-col gap-4 border-b border-white/[0.07] p-5 md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="text-xl font-black text-white">المستخدمون والاشتراكات</h2>
            <p className="mt-1 text-xs text-white/40">آخر تحديث: {formatDate(overview.generatedAt)}</p>
          </div>
          <label className="flex items-center gap-2 rounded-xl border border-white/10 bg-black/20 px-3 py-2 text-sm text-white/60 md:w-80">
            <Search className="h-4 w-4 shrink-0" />
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="ابحث بالاسم أو البريد أو المعرف"
              className="w-full bg-transparent text-right text-white outline-none placeholder:text-white/30"
            />
          </label>
        </div>

        {filteredUsers.length === 0 ? (
          <div className="p-12 text-center text-sm text-white/45">لا يوجد مستخدمون مطابقون للبحث.</div>
        ) : (
          <div className="divide-y divide-white/[0.06]">
            {filteredUsers.map((user) => {
              const userKey = String(user.id);
              const subscriptionKey = `subscription-${user.id}`;
              const isSuspended = user.accessStatus === "suspended";
              const isPaused = user.subscription?.status === "paused";
              return (
                <article key={user.id} className="p-5 transition hover:bg-white/[0.025]">
                  <div className="flex flex-col gap-5 xl:flex-row xl:items-center xl:justify-between">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="font-black text-white">
                          {user.displayName || user.email || `مستخدم #${user.id}`}
                        </h3>
                        <span className={`rounded-full px-2.5 py-1 text-[11px] font-black ${isSuspended ? "bg-rose-500/15 text-rose-200" : "bg-emerald-500/15 text-emerald-200"}`}>
                          {isSuspended ? "موقوف" : "نشط"}
                        </span>
                        {user.subscription ? (
                          <span className="rounded-full bg-cyan-500/15 px-2.5 py-1 text-[11px] font-black text-cyan-200">
                            {user.subscription.planTitle}
                          </span>
                        ) : (
                          <span className="rounded-full bg-white/[0.06] px-2.5 py-1 text-[11px] font-bold text-white/45">
                            تجربة / بدون اشتراك
                          </span>
                        )}
                      </div>
                      <p className="mt-2 truncate text-xs text-white/35" dir="ltr">
                        {user.email || user.clerkUserId}
                      </p>
                      <div className="mt-4 flex flex-wrap gap-x-5 gap-y-2 text-xs text-white/50">
                        <span className="inline-flex items-center gap-1.5"><Activity className="h-3.5 w-3.5 text-cyan-300" />{user.simulationCount} محاكاة</span>
                        <span className="inline-flex items-center gap-1.5"><Clock3 className="h-3.5 w-3.5 text-violet-300" />{user.usageCount} استخدام تجربة</span>
                        <span>انضم {formatDate(user.createdAt)}</span>
                        <span>التجديد {formatDate(user.subscription?.currentPeriodEnd ?? user.trialEndsAt)}</span>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 xl:max-w-[470px] xl:justify-end">
                      <button
                        type="button"
                        onClick={() => window.alert(`معرف الحساب المحلي: ${user.id}\nClerk: ${user.clerkUserId}`)}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 px-3 py-2 text-xs font-bold text-white/60 hover:bg-white/[0.07] hover:text-white"
                      >
                        <Eye className="h-3.5 w-3.5" />
                        التفاصيل
                      </button>
                      <button
                        type="button"
                        disabled={busyAction === `access-${user.id}`}
                        onClick={() =>
                          confirmAction(
                            isSuspended ? "إعادة تفعيل وصول هذا المستخدم؟" : "إيقاف وصول هذا المستخدم فورًا؟",
                            `access-${user.id}`,
                            `/api/admin/users/${user.id}/access`,
                            { action: isSuspended ? "activate" : "suspend" },
                          )
                        }
                        className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-bold disabled:opacity-50 ${isSuspended ? "border-emerald-400/20 bg-emerald-500/10 text-emerald-200 hover:bg-emerald-500/20" : "border-rose-400/20 bg-rose-500/10 text-rose-200 hover:bg-rose-500/20"}`}
                      >
                        {isSuspended ? <CheckCircle2 className="h-3.5 w-3.5" /> : <Ban className="h-3.5 w-3.5" />}
                        {isSuspended ? "تفعيل الوصول" : "إيقاف الوصول"}
                      </button>
                      <button
                        type="button"
                        disabled={busyAction === `logout-${user.id}`}
                        onClick={() =>
                          confirmAction(
                            "سيتم تسجيل خروج هذا المستخدم من كل الجلسات الحالية. متابعة؟",
                            `logout-${user.id}`,
                            `/api/admin/users/${user.id}/revoke-sessions`,
                          )
                        }
                        className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 px-3 py-2 text-xs font-bold text-white/60 hover:bg-white/[0.07] hover:text-white disabled:opacity-50"
                      >
                        <LogOut className="h-3.5 w-3.5" />
                        تسجيل خروج
                      </button>

                      {user.subscription ? (
                        <>
                          {user.subscription.cancelAtPeriodEnd ? (
                            <button
                              type="button"
                              disabled={busyAction === subscriptionKey}
                              onClick={() => confirmAction("إلغاء جدولة إلغاء الاشتراك وإعادته للتجديد؟", subscriptionKey, `/api/admin/subscriptions/${user.subscription?.id}/uncancel`)}
                              className="inline-flex items-center gap-1.5 rounded-lg border border-cyan-400/20 bg-cyan-500/10 px-3 py-2 text-xs font-bold text-cyan-200 hover:bg-cyan-500/20 disabled:opacity-50"
                            >
                              <PlayCircle className="h-3.5 w-3.5" />
                              استئناف التجديد
                            </button>
                          ) : (
                            <button
                              type="button"
                              disabled={busyAction === subscriptionKey}
                              onClick={() => confirmAction("إلغاء التجديد في نهاية الفترة الحالية؟", subscriptionKey, `/api/admin/subscriptions/${user.subscription?.id}/cancel`)}
                              className="inline-flex items-center gap-1.5 rounded-lg border border-rose-400/20 bg-rose-500/10 px-3 py-2 text-xs font-bold text-rose-200 hover:bg-rose-500/20 disabled:opacity-50"
                            >
                              <XCircle className="h-3.5 w-3.5" />
                              إلغاء الاشتراك
                            </button>
                          )}
                          {isPaused ? (
                            <button
                              type="button"
                              disabled={busyAction === subscriptionKey}
                              onClick={() => confirmAction("استئناف تحصيل دفعات هذا الاشتراك؟", subscriptionKey, `/api/admin/subscriptions/${user.subscription?.id}/resume`)}
                              className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-400/20 bg-emerald-500/10 px-3 py-2 text-xs font-bold text-emerald-200 hover:bg-emerald-500/20 disabled:opacity-50"
                            >
                              <PlayCircle className="h-3.5 w-3.5" />
                              استئناف الدفع
                            </button>
                          ) : (
                            <button
                              type="button"
                              disabled={busyAction === subscriptionKey}
                              onClick={() => confirmAction("إيقاف تحصيل الدفعات مؤقتًا مع إبقاء الوصول؟", subscriptionKey, `/api/admin/subscriptions/${user.subscription?.id}/pause`)}
                              className="inline-flex items-center gap-1.5 rounded-lg border border-amber-400/20 bg-amber-500/10 px-3 py-2 text-xs font-bold text-amber-200 hover:bg-amber-500/20 disabled:opacity-50"
                            >
                              <PauseCircle className="h-3.5 w-3.5" />
                              إيقاف الدفع
                            </button>
                          )}
                        </>
                      ) : null}
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}