import { useEffect, useState } from "react";
import { Link } from "wouter";
import { CalendarClock, CheckCircle2, CreditCard, Loader2, ShieldCheck } from "lucide-react";

type BillingState = {
  trialActive: boolean;
  trialEndsAt: string;
  trialUsed: number;
  trialLimit: number;
  trialRemaining: number;
  hasPaidAccess: boolean;
  canSimulate: boolean;
  subscription: {
    status: string;
    currentPeriodEnd: string | null;
    cancelAtPeriodEnd: number;
  } | null;
};

export default function Account() {
  const [account, setAccount] = useState<BillingState | null>(null);
  const [loading, setLoading] = useState(true);
  const [canceling, setCanceling] = useState(false);
  const [message, setMessage] = useState("");

  const loadAccount = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/billing/account", { credentials: "include" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر تحميل الحساب");
      setAccount(data);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "تعذر تحميل الحساب");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadAccount();
  }, []);

  const cancelSubscription = async () => {
    if (!window.confirm("هل تريد إلغاء التجديد في نهاية الفترة الحالية؟")) return;
    setCanceling(true);
    setMessage("");
    try {
      const response = await fetch("/api/billing/cancel", {
        method: "POST",
        credentials: "include",
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر إلغاء الاشتراك");
      setAccount(data.account);
      setMessage("تم تسجيل الإلغاء، وستبقى الخدمة متاحة حتى نهاية الفترة الحالية.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "تعذر إلغاء الاشتراك");
    } finally {
      setCanceling(false);
    }
  };

  if (loading) {
    return <div className="flex min-h-[60vh] items-center justify-center text-white/60"><Loader2 className="h-6 w-6 animate-spin" /></div>;
  }

  const endDate = account?.subscription?.currentPeriodEnd || account?.trialEndsAt;

  return (
    <div className="container mx-auto max-w-4xl px-4 py-10 sm:px-6">
      <div className="mb-8">
        <p className="text-xs font-black uppercase tracking-widest text-cyan-300">حساب MarketSim</p>
        <h1 className="mt-2 text-4xl font-black text-white">حسابك واشتراكك</h1>
      </div>

      {message ? <div className="mb-6 rounded-xl border border-cyan-400/20 bg-cyan-400/10 p-4 text-sm text-cyan-100">{message}</div> : null}

      <div className="grid gap-5 md:grid-cols-2">
        <section className="glass-panel p-6">
          <div className="mb-5 flex items-center gap-3">
            <ShieldCheck className="h-6 w-6 text-emerald-400" />
            <h2 className="text-xl font-black text-white">حالة الوصول</h2>
          </div>
          <div className="rounded-xl border border-white/10 bg-black/20 p-5">
            <p className="text-sm text-white/45">الخطة الحالية</p>
            <p className="mt-1 text-2xl font-black text-white">
              {account?.hasPaidAccess ? "اشتراك مدفوع" : account?.trialActive ? "التجربة المجانية" : "انتهت التجربة"}
            </p>
            <p className="mt-3 text-sm text-white/55">
              {account?.hasPaidAccess
                ? account.subscription?.cancelAtPeriodEnd
                  ? "ملغى عند نهاية الفترة"
                  : "الاشتراك فعال"
                : `${account?.trialRemaining ?? 0} من ${account?.trialLimit ?? 3} محاكاة متبقية`}
            </p>
          </div>
          {endDate ? (
            <div className="mt-4 flex items-center gap-2 text-sm text-white/50">
              <CalendarClock className="h-4 w-4 text-violet-300" />
              حتى {new Date(endDate).toLocaleDateString("ar-SA")}
            </div>
          ) : null}
        </section>

        <section className="glass-panel p-6">
          <div className="mb-5 flex items-center gap-3">
            <CreditCard className="h-6 w-6 text-cyan-300" />
            <h2 className="text-xl font-black text-white">إدارة الاشتراك</h2>
          </div>
          <div className="space-y-3">
            <Link href="/pricing" className="gradient-button flex w-full items-center justify-center rounded-xl px-5 py-3 text-sm font-black">
              {account?.hasPaidAccess ? "تغيير الخطة" : "اختيار خطة مدفوعة"}
            </Link>
            {account?.hasPaidAccess && !account.subscription?.cancelAtPeriodEnd ? (
              <button
                type="button"
                disabled={canceling}
                onClick={cancelSubscription}
                className="w-full rounded-xl border border-rose-400/20 bg-rose-500/10 px-5 py-3 text-sm font-bold text-rose-200 hover:bg-rose-500/20 disabled:opacity-50"
              >
                {canceling ? "جارٍ الإلغاء..." : "إلغاء التجديد"}
              </button>
            ) : null}
          </div>
          <div className="mt-6 flex items-start gap-2 text-xs leading-6 text-white/35">
            <CheckCircle2 className="mt-1 h-4 w-4 shrink-0 text-emerald-400" />
            يتم التحقق من الدفع والعضوية على الخادم عبر Whop، وليس من رابط العودة فقط.
          </div>
        </section>
      </div>
    </div>
  );
}