import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { CheckCircle2, Loader2, XCircle } from "lucide-react";

export default function BillingReturn() {
  const [, setLocation] = useLocation();
  const [status, setStatus] = useState<"loading" | "success" | "error">("loading");
  const [message, setMessage] = useState("");

  useEffect(() => {
    const state = new URLSearchParams(window.location.search).get("state");
    if (!state) {
      setStatus("error");
      setMessage("رابط العودة غير مكتمل.");
      return;
    }

    fetch("/api/billing/sync", {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ state }),
    })
      .then(async (response) => {
        const data = await response.json();
        if (!response.ok || !data.verified) {
          throw new Error(data.error || "لم يتم تأكيد الدفع بعد.");
        }
        setStatus("success");
        setTimeout(() => setLocation("/account"), 1200);
      })
      .catch((error) => {
        setStatus("error");
        setMessage(error instanceof Error ? error.message : "تعذر تأكيد الدفع.");
      });
  }, [setLocation]);

  return (
    <div className="flex min-h-[60vh] items-center justify-center px-4">
      <div className="glass-panel max-w-lg p-8 text-center">
        {status === "loading" ? <Loader2 className="mx-auto h-12 w-12 animate-spin text-cyan-300" /> : null}
        {status === "success" ? <CheckCircle2 className="mx-auto h-12 w-12 text-emerald-400" /> : null}
        {status === "error" ? <XCircle className="mx-auto h-12 w-12 text-rose-400" /> : null}
        <h1 className="mt-5 text-2xl font-black text-white">
          {status === "loading" ? "جارٍ تأكيد الدفع..." : status === "success" ? "تم تفعيل اشتراكك" : "تعذر تأكيد الدفع"}
        </h1>
        {message ? <p className="mt-3 text-sm leading-7 text-white/55">{message}</p> : null}
        {status === "error" ? (
          <Link href="/account" className="gradient-button mt-6 inline-flex rounded-xl px-6 py-3 text-sm font-black">
            العودة إلى الحساب
          </Link>
        ) : null}
      </div>
    </div>
  );
}