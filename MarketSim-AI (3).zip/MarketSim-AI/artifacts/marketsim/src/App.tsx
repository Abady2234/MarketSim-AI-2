import { Switch, Route, Router as WouterRouter } from "wouter";
import { Redirect, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  ClerkProvider,
  SignIn,
  SignUp,
  useAuth,
  useClerk,
} from "@clerk/react";
import { publishableKeyFromHost } from "@clerk/react/internal";
import { shadcn } from "@clerk/themes";
import { useEffect, useRef } from "react";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Shell } from "@/components/layout/Shell";
import Home from "@/pages/Home";
import Simulate from "@/pages/Simulate";
import SimulationDetail from "@/pages/SimulationDetail";
import History from "@/pages/History";
import Pricing from "@/pages/Pricing";
import Account from "@/pages/Account";
import BillingReturn from "@/pages/BillingReturn";
import Admin from "@/pages/Admin";
import NotFound from "@/pages/not-found";
import InstallPrompt from "@/components/InstallPrompt";

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

function LoadingScreen() {
  return (
    <div className="min-h-[100dvh] flex items-center justify-center text-white/60">
      <div className="flex items-center gap-3 text-sm font-bold">
        <div className="h-4 w-4 rounded-full border-2 border-cyan-400 border-t-transparent animate-spin" />
        جارٍ تجهيز حسابك...
      </div>
    </div>
  );
}

function HomeRoute() {
  const { isLoaded, isSignedIn } = useAuth();
  if (!isLoaded) return <LoadingScreen />;
  if (isSignedIn) return <Redirect to="/dashboard" />;
  return <Home />;
}

function ProtectedApp() {
  const { isLoaded, isSignedIn } = useAuth();
  if (!isLoaded) return <LoadingScreen />;
  if (!isSignedIn) return <Redirect to="/sign-in" />;

  return (
    <Shell>
      <Switch>
        <Route path="/dashboard" component={Home} />
        <Route path="/simulate" component={Simulate} />
        <Route path="/simulation/:id" component={SimulationDetail} />
        <Route path="/history" component={History} />
        <Route path="/pricing" component={Pricing} />
        <Route path="/account" component={Account} />
        <Route path="/billing/return" component={BillingReturn} />
        <Route path="/admin" component={Admin} />
        <Route component={NotFound} />
      </Switch>
    </Shell>
  );
}

function SignInPage() {
  return (
    <div className="min-h-[100dvh] flex items-center justify-center px-4 py-10">
      <SignIn
        routing="path"
        path={`${basePath}/sign-in`}
        signUpUrl={`${basePath}/sign-up`}
      />
    </div>
  );
}

function SignUpPage() {
  return (
    <div className="min-h-[100dvh] flex items-center justify-center px-4 py-10">
      <SignUp
        routing="path"
        path={`${basePath}/sign-up`}
        signInUrl={`${basePath}/sign-in`}
      />
    </div>
  );
}

function HomeAndProtectedRoutes() {
  return (
    <Switch>
      <Route path="/" component={HomeRoute} />
      <Route path="/sign-in/*?" component={SignInPage} />
      <Route path="/sign-up/*?" component={SignUpPage} />
      <Route component={ProtectedApp} />
    </Switch>
  );
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const previousUserId = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const nextUserId = user?.id ?? null;
      if (
        previousUserId.current !== undefined &&
        previousUserId.current !== nextUserId
      ) {
        queryClient.clear();
      }
      previousUserId.current = nextUserId;
    });
    return unsubscribe;
  }, [addListener]);

  return null;
}

function ClerkApp() {
  const [, setLocation] = useLocation();
  const stripBase = (path: string) =>
    basePath && path.startsWith(basePath)
      ? path.slice(basePath.length) || "/"
      : path;

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={{
        theme: shadcn,
        cssLayerName: "clerk",
        options: {
          logoPlacement: "inside",
          logoLinkUrl: basePath || "/",
          logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
        },
        variables: {
          colorPrimary: "#8b5cf6",
          colorForeground: "#f4f2ff",
          colorMutedForeground: "#a7a1bd",
          colorBackground: "#120c2b",
          colorInput: "#0b071b",
          colorInputForeground: "#ffffff",
          colorDanger: "#fb7185",
          colorNeutral: "#332b54",
          fontFamily: "Tajawal, sans-serif",
          borderRadius: "0.85rem",
        },
        elements: {
          rootBox: "w-full flex justify-center",
          cardBox: "bg-[#120c2b] rounded-2xl w-[440px] max-w-full overflow-hidden border border-white/10 shadow-2xl",
          card: "!shadow-none !border-0 !bg-transparent !rounded-none",
          footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
          headerTitle: "text-white font-black",
          headerSubtitle: "text-white/60",
          socialButtonsBlockButtonText: "text-white",
          formFieldLabel: "text-white/80",
          footerActionLink: "text-cyan-300 hover:text-cyan-200",
          footerActionText: "text-white/60",
          dividerText: "text-white/50",
          formFieldInput: "bg-black/30 text-white border-white/10",
          formButtonPrimary: "gradient-button",
          socialButtonsBlockButton: "bg-white/[0.06] border-white/10 hover:bg-white/[0.1]",
          formFieldSuccessText: "text-emerald-300",
          alertText: "text-rose-200",
          logoBox: "rounded-xl overflow-hidden",
          logoImage: "object-contain",
          footerAction: "text-white/60",
          dividerLine: "bg-white/10",
          alert: "bg-rose-500/10 border-rose-400/20",
          otpCodeFieldInput: "bg-black/30 text-white border-white/10",
          formFieldRow: "text-white",
          main: "bg-transparent",
        },
      }}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: {
          start: {
            title: "مرحبًا بعودتك",
            subtitle: "سجّل الدخول للوصول إلى حسابك ومحاكياتك",
          },
        },
        signUp: {
          start: {
            title: "أنشئ حسابك",
            subtitle: "ابدأ تجربتك المجانية لمدة 3 أيام",
          },
        },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <ClerkQueryClientCacheInvalidator />
        <HomeAndProtectedRoutes />
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  if (!clerkPubKey) {
    throw new Error("Missing VITE_CLERK_PUBLISHABLE_KEY");
  }

  return (
    <TooltipProvider>
      <WouterRouter base={basePath}>
        <ClerkApp />
      </WouterRouter>
      <InstallPrompt />
      <Toaster />
    </TooltipProvider>
  );
}

export default App;
