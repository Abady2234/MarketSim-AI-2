import { and, eq, gt, sql } from "drizzle-orm";
import {
  checkoutSessionsTable,
  db,
  subscriptionsTable,
  usageTable,
  usersTable,
  type User,
} from "@workspace/db";
import { getWhopClient } from "./whopClient";

export const FREE_TRIAL_DAYS = 3;
export const FREE_TRIAL_SIMULATION_LIMIT = 3;

export const PLAN_CATALOG = [
  {
    key: "monthly",
    planId: process.env.WHOP_PLAN_MONTHLY ?? "plan_vT1X5U4KIV7fJ",
    title: "شهري",
    price: 50,
    periodLabel: "شهريًا",
    description: "للتجارب السريعة وإطلاق أفكار جديدة كل شهر",
  },
  {
    key: "quarterly",
    planId: process.env.WHOP_PLAN_QUARTERLY ?? "plan_JQF1Mq3jsVsTu",
    title: "3 أشهر",
    price: 100,
    periodLabel: "كل 3 أشهر",
    description: "أفضل قيمة لبناء قرارات متتالية",
  },
  {
    key: "semiannual",
    planId: process.env.WHOP_PLAN_SEMIANNUAL ?? "plan_JBIv75gMREAlq",
    title: "6 أشهر",
    price: 250,
    periodLabel: "كل 6 أشهر",
    description: "للفرق والمشاريع التي تختبر السوق باستمرار",
  },
] as const;

export type PlanKey = (typeof PLAN_CATALOG)[number]["key"];

export function getPlan(planKey: string) {
  return PLAN_CATALOG.find((plan) => plan.key === planKey);
}

function isWhopActiveStatus(status: string) {
  return ["active", "trialing"].includes(status);
}

async function syncWhopSubscription(subscription: typeof subscriptionsTable.$inferSelect) {
  if (!subscription.membershipId) return false;

  try {
    const whop = await getWhopClient();
    const membership = await whop.memberships.retrieve(subscription.membershipId);
    const isActive = isWhopActiveStatus(membership.status);
    const periodEnd = membership.renewal_period_end
      ? new Date(membership.renewal_period_end)
      : null;

    await db
      .update(subscriptionsTable)
      .set({
        status: membership.status,
        currentPeriodEnd: periodEnd,
        cancelAtPeriodEnd: membership.cancel_at_period_end ? 1 : 0,
        updatedAt: new Date(),
        lastSyncedAt: new Date(),
      })
      .where(eq(subscriptionsTable.id, subscription.id));

    return isActive;
  } catch {
    return false;
  }
}

export async function getActiveSubscription(userId: number) {
  const subscriptions = await db
    .select()
    .from(subscriptionsTable)
    .where(
      and(
        eq(subscriptionsTable.userId, userId),
        eq(subscriptionsTable.provider, "whop"),
        gt(subscriptionsTable.currentPeriodEnd, new Date()),
      ),
    )
    .orderBy(sql`${subscriptionsTable.updatedAt} desc`)
    .limit(1);

  const subscription = subscriptions[0];
  if (!subscription) return null;
  return (await syncWhopSubscription(subscription)) ? subscription : null;
}

async function getTrialUsage(user: User) {
  const rows = await db
    .select()
    .from(usageTable)
    .where(
      and(
        eq(usageTable.userId, user.id),
        eq(usageTable.periodStart, user.trialStartedAt),
      ),
    )
    .limit(1);
  return rows[0]?.simulationCount ?? 0;
}

export async function getBillingState(user: User) {
  const subscription = await getActiveSubscription(user.id);
  const now = new Date();
  const trialActive = user.trialEndsAt > now;
  const trialUsed = await getTrialUsage(user);

  return {
    trialActive,
    trialEndsAt: user.trialEndsAt,
    trialUsed,
    trialLimit: FREE_TRIAL_SIMULATION_LIMIT,
    trialRemaining: Math.max(FREE_TRIAL_SIMULATION_LIMIT - trialUsed, 0),
    subscription,
    hasPaidAccess: Boolean(subscription),
    canSimulate: Boolean(subscription) || (trialActive && trialUsed < FREE_TRIAL_SIMULATION_LIMIT),
  };
}

export async function assertSimulationAccess(user: User) {
  const state = await getBillingState(user);
  if (state.canSimulate) return state;

  const message = state.trialActive
    ? "انتهت محاولات التجربة المجانية. اختر خطة للمتابعة."
    : "انتهت التجربة المجانية. اختر خطة للمتابعة.";
  const error = new Error(message);
  error.name = "BillingLimitError";
  throw error;
}

export async function recordSimulationUsage(user: User) {
  const state = await getBillingState(user);
  if (state.hasPaidAccess) return;

  await db
    .insert(usageTable)
    .values({
      userId: user.id,
      periodStart: user.trialStartedAt,
      simulationCount: 1,
    })
    .onConflictDoUpdate({
      target: [usageTable.userId, usageTable.periodStart],
      set: {
        simulationCount: sql`${usageTable.simulationCount} + 1`,
        updatedAt: new Date(),
      },
    });
}

export async function createCheckoutSession(
  user: User,
  planKey: string,
  state: string,
  redirectUrl: string,
) {
  const plan = getPlan(planKey);
  if (!plan) throw new Error("Unknown subscription plan");

  const whop = await getWhopClient();
  const checkout = await whop.checkoutConfigurations.create({
    plan_id: plan.planId,
    redirect_url: redirectUrl,
    metadata: {
      marketsim_user_id: String(user.id),
      marketsim_clerk_user_id: user.clerkUserId,
    },
  });

  await db.insert(checkoutSessionsTable).values({
    userId: user.id,
    checkoutId: checkout.id,
    planId: plan.planId,
    stateHash: state,
  });

  return { checkout, plan };
}

export async function syncCheckoutSession(user: User, checkoutId: string) {
  const sessions = await db
    .select()
    .from(checkoutSessionsTable)
    .where(
      and(
        eq(checkoutSessionsTable.userId, user.id),
        eq(checkoutSessionsTable.checkoutId, checkoutId),
      ),
    )
    .limit(1);
  const session = sessions[0];
  if (!session) return { verified: false };

  const whop = await getWhopClient();
  const checkout = await whop.checkoutConfigurations.retrieve(checkoutId);
  const payments = [];
  for await (const payment of whop.payments.list({
    checkout_configuration_ids: [checkoutId],
  })) {
    payments.push(payment);
  }

  const successfulPayment = payments.find((payment) =>
    ["succeeded", "paid", "completed"].includes(payment.status ?? ""),
  );
  const membershipId = successfulPayment?.membership?.id ?? null;
  if (!successfulPayment || !membershipId) {
    return { verified: false, checkout };
  }

  const membership = await whop.memberships.retrieve(membershipId);
  if (!isWhopActiveStatus(membership.status)) {
    return { verified: false, checkout };
  }

  await db
    .insert(subscriptionsTable)
    .values({
      userId: user.id,
      planId: session.planId,
      membershipId: membership.id,
      checkoutId,
      status: membership.status,
      currentPeriodEnd: membership.renewal_period_end
        ? new Date(membership.renewal_period_end)
        : null,
      cancelAtPeriodEnd: membership.cancel_at_period_end ? 1 : 0,
      lastSyncedAt: new Date(),
    })
    .onConflictDoNothing({ target: subscriptionsTable.membershipId });

  await db
    .update(checkoutSessionsTable)
    .set({ status: "completed", completedAt: new Date() })
    .where(eq(checkoutSessionsTable.id, session.id));

  return { verified: true, checkout, membership };
}