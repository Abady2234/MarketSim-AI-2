import { Router } from "express";
import { createHash, createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { and, eq } from "drizzle-orm";
import { db, checkoutSessionsTable, subscriptionsTable } from "@workspace/db";
import { getOrCreateLocalUser, requireAuth } from "../../middlewares/auth";
import {
  PLAN_CATALOG,
  createCheckoutSession,
  getBillingState,
  syncCheckoutSession,
} from "../../lib/billing";
import { getWhopClient } from "../../lib/whopClient";

const router = Router();
const stateSecret = process.env.SESSION_SECRET ?? "marketsim-development-secret";

function signState(payload: string) {
  return createHmac("sha256", stateSecret).update(payload).digest("base64url");
}

function createState(userId: number, planKey: string) {
  const payload = Buffer.from(
    JSON.stringify({ userId, planKey, nonce: randomBytes(18).toString("hex") }),
  ).toString("base64url");
  return `${payload}.${signState(payload)}`;
}

function isValidState(state: string) {
  const [payload, signature] = state.split(".");
  if (!payload || !signature) return null;
  const expected = signState(payload);
  if (
    signature.length !== expected.length ||
    !timingSafeEqual(Buffer.from(signature), Buffer.from(expected))
  ) {
    return null;
  }
  try {
    return JSON.parse(Buffer.from(payload, "base64url").toString("utf8")) as {
      userId: number;
      planKey: string;
    };
  } catch {
    return null;
  }
}

function publicOrigin(req: { headers: Record<string, string | string[] | undefined> }) {
  const configuredOrigin = process.env.REPLIT_APP_URL?.trim().replace(/\/+$/, "");
  if (configuredOrigin) return configuredOrigin;

  const forwardedHost = req.headers["x-forwarded-host"];
  const host = (Array.isArray(forwardedHost) ? forwardedHost[0] : forwardedHost) ?? req.headers.host;
  const forwardedProto = req.headers["x-forwarded-proto"];
  const protocol = (Array.isArray(forwardedProto) ? forwardedProto[0] : forwardedProto) ?? "https";
  return `${protocol}://${host}`;
}

router.get("/billing/plans", (_req, res) => {
  res.json({
    plans: PLAN_CATALOG,
    custom: {
      key: "custom",
      title: "خطة مخصصة",
      description: "تواصل معنا لبناء باقة تناسب فريقك وحجم الاستخدام.",
    },
  });
});

router.get("/billing/account", requireAuth, async (req, res) => {
  try {
    const user = await getOrCreateLocalUser(req);
    const state = await getBillingState(user);
    res.json({
      user: { id: user.id, createdAt: user.createdAt, trialStartedAt: user.trialStartedAt },
      ...state,
    });
  } catch {
    res.status(500).json({ error: "Failed to load billing account" });
  }
});

router.post("/billing/checkout", requireAuth, async (req, res) => {
  try {
    const user = await getOrCreateLocalUser(req);
    const planKey = typeof req.body?.planKey === "string" ? req.body.planKey : "";
    const state = createState(user.id, planKey);
    const stateHash = createHash("sha256").update(state).digest("hex");
    const redirectUrl = `${publicOrigin(req)}/billing/return?state=${encodeURIComponent(state)}`;
    const result = await createCheckoutSession(user, planKey, stateHash, redirectUrl);
    res.json({
      purchaseUrl: result.checkout.purchase_url,
      checkoutId: result.checkout.id,
      plan: result.plan,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unable to create checkout";
    res.status(400).json({ error: message });
  }
});

router.post("/billing/sync", requireAuth, async (req, res) => {
  try {
    const user = await getOrCreateLocalUser(req);
    const state = typeof req.body?.state === "string" ? req.body.state : "";
    const decoded = isValidState(state);
    if (!decoded || decoded.userId !== user.id) {
      res.status(400).json({ error: "Invalid checkout state" });
      return;
    }
    const stateHash = createHash("sha256").update(state).digest("hex");
    const sessions = await db
      .select()
      .from(checkoutSessionsTable)
      .where(
        and(
          eq(checkoutSessionsTable.userId, user.id),
          eq(checkoutSessionsTable.stateHash, stateHash),
        ),
      )
      .limit(1);
    if (!sessions[0]) {
      res.status(404).json({ error: "Checkout session not found" });
      return;
    }
    const result = await syncCheckoutSession(user, sessions[0].checkoutId);
    res.json({ ...result, account: await getBillingState(user) });
  } catch {
    res.status(500).json({ error: "Unable to verify checkout yet" });
  }
});

router.post("/billing/cancel", requireAuth, async (req, res) => {
  try {
    const user = await getOrCreateLocalUser(req);
    const state = await getBillingState(user);
    if (!state.subscription?.membershipId) {
      res.status(404).json({ error: "No active subscription" });
      return;
    }
    const whop = await getWhopClient();
    await whop.memberships.cancel(state.subscription.membershipId, {
      cancellation_mode: "at_period_end",
    });
    res.json({ account: await getBillingState(user) });
  } catch {
    res.status(500).json({ error: "Unable to cancel subscription" });
  }
});

export default router;