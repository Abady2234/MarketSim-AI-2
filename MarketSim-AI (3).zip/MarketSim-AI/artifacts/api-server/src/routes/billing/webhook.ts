import { Router } from "express";
import { db, subscriptionsTable, webhookEventsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { getWhopClient } from "../../lib/whopClient";

const router = Router();

router.post("/", async (req, res) => {
  const rawBody = Buffer.isBuffer(req.body)
    ? req.body.toString("utf8")
    : JSON.stringify(req.body ?? {});
  const signature = String(req.headers["whop-signature"] ?? "");
  const webhookSecret = process.env.WHOP_WEBHOOK_SECRET;

  try {
    const whop = await getWhopClient();
    const event = whop.webhooks.unwrap(rawBody, {
      headers: { "whop-signature": signature },
      key: webhookSecret,
    }) as { id?: string; type?: string; data?: { id?: string; status?: string } };

    if (!event.id || !event.type) {
      res.status(400).json({ error: "Invalid webhook event" });
      return;
    }

    const inserted = await db
      .insert(webhookEventsTable)
      .values({
        eventId: event.id,
        eventType: event.type,
        payload: rawBody,
      })
      .onConflictDoNothing({ target: webhookEventsTable.eventId })
      .returning();

    if (inserted[0] && event.data?.id && event.type.startsWith("membership.")) {
      await db
        .update(subscriptionsTable)
        .set({
          status: event.data.status ?? "unknown",
          updatedAt: new Date(),
          lastSyncedAt: new Date(),
        })
        .where(eq(subscriptionsTable.membershipId, event.data.id));
    }

    res.status(200).json({ received: true });
  } catch {
    res.status(400).json({ error: "Invalid webhook signature or payload" });
  }
});

export default router;