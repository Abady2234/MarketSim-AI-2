import { Router } from "express";
import { clerkClient } from "@clerk/express";
import type { NextFunction, Request, Response } from "express";
import { desc, eq } from "drizzle-orm";
import {
  checkoutSessionsTable,
  db,
  simulationsTable,
  subscriptionsTable,
  usageTable,
  usersTable,
} from "@workspace/db";
import { getAuth } from "@clerk/express";
import { getOrCreateLocalUser, requireAuth } from "../../middlewares/auth";
import { getWhopClient } from "../../lib/whopClient";
import { PLAN_CATALOG } from "../../lib/billing";

const router = Router();

const adminIds = () =>
  new Set(
    (process.env.ADMIN_CLERK_USER_IDS ?? "")
      .split(",")
      .map((id) => id.trim())
      .filter(Boolean),
  );

function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const clerkUserId = req.userId ?? getAuth(req).userId;
  if (!clerkUserId || !adminIds().has(clerkUserId)) {
    res.status(403).json({ error: "Admin access required" });
    return;
  }
  next();
}

router.use(requireAuth, requireAdmin);

const planById = new Map(PLAN_CATALOG.map((plan) => [plan.planId, plan]));

function serializeUser(
  user: typeof usersTable.$inferSelect,
  simulationCount: number,
  usageCount: number,
  subscription: typeof subscriptionsTable.$inferSelect | undefined,
  profile?: { email: string | null; displayName: string | null },
) {
  const plan = subscription ? planById.get(subscription.planId) : undefined;
  return {
    id: user.id,
    clerkUserId: user.clerkUserId,
    email: profile?.email ?? user.email,
    displayName: profile?.displayName ?? user.displayName,
    accessStatus: user.accessStatus,
    suspendedAt: user.suspendedAt,
    suspensionReason: user.suspensionReason,
    trialStartedAt: user.trialStartedAt,
    trialEndsAt: user.trialEndsAt,
    createdAt: user.createdAt,
    updatedAt: user.updatedAt,
    simulationCount,
    usageCount,
    subscription: subscription
      ? {
          id: subscription.id,
          planId: subscription.planId,
          planTitle: plan?.title ?? subscription.planId,
          planPrice: plan?.price ?? null,
          membershipId: subscription.membershipId,
          status: subscription.status,
          currentPeriodEnd: subscription.currentPeriodEnd,
          cancelAtPeriodEnd: Boolean(subscription.cancelAtPeriodEnd),
        }
      : null,
  };
}

router.get("/admin/overview", async (_req, res) => {
  try {
    const now = new Date();
    const [users, subscriptions, usage, simulations, checkouts] = await Promise.all([
      db.select().from(usersTable).orderBy(desc(usersTable.createdAt)),
      db.select().from(subscriptionsTable).orderBy(desc(subscriptionsTable.createdAt)),
      db.select().from(usageTable),
      db.select({ id: simulationsTable.id, userId: simulationsTable.userId, createdAt: simulationsTable.createdAt }).from(simulationsTable),
      db.select().from(checkoutSessionsTable),
    ]);

    const activeSubscriptions = subscriptions.filter(
      (subscription) =>
        ["active", "trialing"].includes(subscription.status) &&
        Boolean(subscription.currentPeriodEnd && subscription.currentPeriodEnd > now),
    );
    const estimatedRevenue = subscriptions
      .filter((subscription) => subscription.status !== "pending")
      .reduce((total, subscription) => total + (planById.get(subscription.planId)?.price ?? 0), 0);

    const simulationCounts = new Map<number, number>();
    for (const simulation of simulations) {
      if (simulation.userId) {
        simulationCounts.set(simulation.userId, (simulationCounts.get(simulation.userId) ?? 0) + 1);
      }
    }
    const usageCounts = new Map<number, number>();
    for (const row of usage) usageCounts.set(row.userId, (usageCounts.get(row.userId) ?? 0) + row.simulationCount);
    const latestSubscriptions = new Map<number, typeof subscriptionsTable.$inferSelect>();
    for (const subscription of subscriptions) {
      if (!latestSubscriptions.has(subscription.userId)) latestSubscriptions.set(subscription.userId, subscription);
    }

    const profiles = await Promise.all(
      users.map(async (user) => {
        try {
          const clerkUser = await clerkClient.users.getUser(user.clerkUserId);
          return [
            user.id,
            {
              email: clerkUser.primaryEmailAddress?.emailAddress ?? null,
              displayName:
                [clerkUser.firstName, clerkUser.lastName].filter(Boolean).join(" ") ||
                clerkUser.username ||
                null,
            },
          ] as const;
        } catch {
          return [user.id, { email: null, displayName: null }] as const;
        }
      }),
    );
    const profileByUserId = new Map(profiles);

    res.json({
      generatedAt: now,
      metrics: {
        totalUsers: users.length,
        activeSubscribers: activeSubscriptions.length,
        trialUsers: users.filter((user) => user.trialEndsAt > now && user.accessStatus === "active").length,
        suspendedUsers: users.filter((user) => user.accessStatus === "suspended").length,
        totalSimulations: simulations.length,
        totalUsage: usage.reduce((total, row) => total + row.simulationCount, 0),
        completedCheckouts: checkouts.filter((checkout) => checkout.status === "completed").length,
        estimatedRevenue,
      },
      users: users.map((user) =>
        serializeUser(
          user,
          simulationCounts.get(user.id) ?? 0,
          usageCounts.get(user.id) ?? 0,
          latestSubscriptions.get(user.id),
          profileByUserId.get(user.id),
        ),
      ),
    });
  } catch {
    res.status(500).json({ error: "Unable to load admin overview" });
  }
});

router.post("/admin/users/:id/access", async (req, res) => {
  const userId = Number(req.params.id);
  const action = req.body?.action;
  if (!Number.isInteger(userId) || !["suspend", "activate"].includes(action)) {
    res.status(400).json({ error: "Invalid access action" });
    return;
  }

  try {
    const admin = await getOrCreateLocalUser(req);
    if (admin.id === userId) {
      res.status(400).json({ error: "You cannot suspend your own admin account" });
      return;
    }
    const updated = await db
      .update(usersTable)
      .set(
        action === "suspend"
          ? {
              accessStatus: "suspended",
              suspendedAt: new Date(),
              suspensionReason: typeof req.body?.reason === "string" ? req.body.reason.slice(0, 500) : "Suspended by administrator",
              updatedAt: new Date(),
            }
          : {
              accessStatus: "active",
              suspendedAt: null,
              suspensionReason: null,
              updatedAt: new Date(),
            },
      )
      .where(eq(usersTable.id, userId))
      .returning();
    if (!updated[0]) {
      res.status(404).json({ error: "User not found" });
      return;
    }
    res.json({ user: updated[0] });
  } catch {
    res.status(500).json({ error: "Unable to update user access" });
  }
});

router.post("/admin/users/:id/revoke-sessions", async (req, res) => {
  const userId = Number(req.params.id);
  if (!Number.isInteger(userId)) {
    res.status(400).json({ error: "Invalid user ID" });
    return;
  }
  try {
    const users = await db.select().from(usersTable).where(eq(usersTable.id, userId)).limit(1);
    const target = users[0];
    if (!target) {
      res.status(404).json({ error: "User not found" });
      return;
    }
    const sessions = await clerkClient.sessions.getSessionList({ userId: target.clerkUserId });
    await Promise.all(sessions.data.map((session) => clerkClient.sessions.revokeSession(session.id)));
    res.json({ revoked: sessions.data.length });
  } catch {
    res.status(500).json({ error: "Unable to revoke user sessions" });
  }
});

router.post("/admin/subscriptions/:id/:action", async (req, res) => {
  const subscriptionId = Number(req.params.id);
  const action = req.params.action;
  if (!Number.isInteger(subscriptionId) || !["cancel", "uncancel", "pause", "resume"].includes(action)) {
    res.status(400).json({ error: "Invalid subscription action" });
    return;
  }

  try {
    const rows = await db
      .select()
      .from(subscriptionsTable)
      .where(eq(subscriptionsTable.id, subscriptionId))
      .limit(1);
    const subscription = rows[0];
    if (!subscription?.membershipId) {
      res.status(404).json({ error: "Subscription or membership not found" });
      return;
    }

    const whop = await getWhopClient();
    if (action === "cancel") {
      await whop.memberships.cancel(subscription.membershipId, { cancellation_mode: "at_period_end" });
    } else if (action === "uncancel") {
      await whop.memberships.uncancel(subscription.membershipId);
    } else if (action === "pause") {
      await whop.memberships.pause(subscription.membershipId);
    } else {
      await whop.memberships.resume(subscription.membershipId);
    }

    const updated = await db
      .update(subscriptionsTable)
      .set({
        cancelAtPeriodEnd: action === "cancel" ? 1 : action === "uncancel" ? 0 : subscription.cancelAtPeriodEnd,
        status: action === "pause" ? "paused" : action === "resume" ? "active" : subscription.status,
        updatedAt: new Date(),
        lastSyncedAt: new Date(),
      })
      .where(eq(subscriptionsTable.id, subscriptionId))
      .returning();

    res.json({ subscription: updated[0] });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unable to update subscription";
    res.status(400).json({ error: message });
  }
});

export default router;