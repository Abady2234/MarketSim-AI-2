import { Router } from "express";
import { db } from "@workspace/db";
import {
  simulationsTable,
  personasTable,
  simulationReportsTable,
} from "@workspace/db";
import {
  CreateSimulationBody,
  GetSimulationParams,
  DeleteSimulationParams,
  RunSimulationParams,
} from "@workspace/api-zod";
import { eq, desc, avg, count, isNotNull, and } from "drizzle-orm";
import { runSimulationEngine } from "./engine";
import { getOrCreateLocalUser, requireAuth } from "../../middlewares/auth";
import { assertSimulationAccess, recordSimulationUsage } from "../../lib/billing";

const router = Router();
router.use(requireAuth);

router.get("/simulations", async (req, res) => {
  try {
    const user = await getOrCreateLocalUser(req);
    const simulations = await db
      .select()
      .from(simulationsTable)
      .where(eq(simulationsTable.userId, user.id))
      .orderBy(desc(simulationsTable.createdAt));
    res.json(simulations);
  } catch {
    res.status(500).json({ error: "Failed to list simulations" });
  }
});

router.get("/simulations/stats", async (req, res) => {
  try {
    const user = await getOrCreateLocalUser(req);
    const [totalResult, completedResult, avgResult, recentSimulations] = await Promise.all([
      db.select({ count: count() }).from(simulationsTable).where(eq(simulationsTable.userId, user.id)),
      db
        .select({ count: count() })
        .from(simulationsTable)
        .where(and(eq(simulationsTable.status, "completed"), eq(simulationsTable.userId, user.id))),
      db
        .select({ avg: avg(simulationsTable.acceptanceRate) })
        .from(simulationsTable)
        .where(and(isNotNull(simulationsTable.acceptanceRate), eq(simulationsTable.userId, user.id))),
      db
        .select()
        .from(simulationsTable)
        .where(eq(simulationsTable.userId, user.id))
        .orderBy(desc(simulationsTable.createdAt))
        .limit(5),
    ]);

    res.json({
      totalSimulations: totalResult[0]?.count ?? 0,
      completedSimulations: completedResult[0]?.count ?? 0,
      avgAcceptanceRate: avgResult[0]?.avg ?? null,
      recentSimulations,
    });
  } catch {
    res.status(500).json({ error: "Failed to get stats" });
  }
});

router.get("/simulations/:id", async (req, res) => {
  const params = GetSimulationParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid simulation ID" });
    return;
  }

  try {
    const user = await getOrCreateLocalUser(req);
    const [simulation, personas, reports] = await Promise.all([
      db
        .select()
        .from(simulationsTable)
        .where(and(eq(simulationsTable.id, params.data.id), eq(simulationsTable.userId, user.id)))
        .limit(1),
      db
        .select()
        .from(personasTable)
        .where(eq(personasTable.simulationId, params.data.id))
        .orderBy(personasTable.orderIndex),
      db
        .select()
        .from(simulationReportsTable)
        .where(eq(simulationReportsTable.simulationId, params.data.id))
        .limit(1),
    ]);

    if (!simulation[0]) {
      res.status(404).json({ error: "Simulation not found" });
      return;
    }

    res.json({
      ...simulation[0],
      personas,
      report: reports[0] ?? null,
    });
  } catch {
    res.status(500).json({ error: "Failed to get simulation" });
  }
});

router.post("/simulations", async (req, res) => {
  const body = CreateSimulationBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  try {
    const user = await getOrCreateLocalUser(req);
    await assertSimulationAccess(user);
    const inserted = await db
      .insert(simulationsTable)
      .values({
        userId: user.id,
        title: "محاكاة جديدة",
        ideaText: body.data.ideaText,
        income: body.data.income ?? null,
        price: body.data.price ?? null,
        image1Url: body.data.image1Url ?? null,
        image2Url: body.data.image2Url ?? null,
        numPersonas: body.data.numPersonas ?? 7,
        targetAge: body.data.targetAge ?? null,
        targetCity: body.data.targetCity ?? null,
        problemSolved: body.data.problemSolved ?? null,
        competitors: body.data.competitors ?? null,
        extraDetails: body.data.extraDetails ?? null,
        simulationMode: body.data.simulationMode ?? "concept",
        status: "pending",
      })
      .returning();

    await recordSimulationUsage(user);
    res.status(201).json(inserted[0]);
  } catch (error) {
    if (error instanceof Error && error.name === "BillingLimitError") {
      res.status(402).json({ error: error.message });
      return;
    }
    res.status(500).json({ error: "Failed to create simulation" });
  }
});

router.delete("/simulations/:id", async (req, res) => {
  const params = DeleteSimulationParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid simulation ID" });
    return;
  }

  try {
    const user = await getOrCreateLocalUser(req);
    const deleted = await db
      .delete(simulationsTable)
      .where(and(eq(simulationsTable.id, params.data.id), eq(simulationsTable.userId, user.id)))
      .returning();

    if (!deleted[0]) {
      res.status(404).json({ error: "Simulation not found" });
      return;
    }

    res.status(204).send();
  } catch {
    res.status(500).json({ error: "Failed to delete simulation" });
  }
});

router.post("/simulations/:id/run", async (req, res) => {
  const params = RunSimulationParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid simulation ID" });
    return;
  }

  let user;
  try {
    user = await getOrCreateLocalUser(req);
  } catch (error) {
    res.status(500).json({ error: "Unable to authorize simulation" });
    return;
  }
  const simulation = await db
    .select()
    .from(simulationsTable)
    .where(and(eq(simulationsTable.id, params.data.id), eq(simulationsTable.userId, user.id)))
    .limit(1);

  if (!simulation[0]) {
    res.status(404).json({ error: "Simulation not found" });
    return;
  }

  // Creating a pending simulation reserves one trial slot. A first run must
  // therefore not consume/check the same slot a second time. Re-running an
  // existing simulation still requires active paid/trial access.
  if (simulation[0].status !== "pending") {
    try {
      await assertSimulationAccess(user);
    } catch (error) {
      if (error instanceof Error && error.name === "BillingLimitError") {
        res.status(402).json({ error: error.message });
        return;
      }
      res.status(500).json({ error: "Unable to authorize simulation" });
      return;
    }
  }

  if (simulation[0].status === "running") {
    res.status(409).json({ error: "Simulation is already running" });
    return;
  }

  // Allow re-running completed or failed simulations

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.flushHeaders();

  await runSimulationEngine(params.data.id, res);
});

export default router;
