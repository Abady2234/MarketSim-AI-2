import { getAuth } from "@clerk/express";
import type { NextFunction, Request, Response } from "express";
import { and, eq } from "drizzle-orm";
import { db, usersTable, type User } from "@workspace/db";

declare global {
  namespace Express {
    interface Request {
      userId?: string;
      localUser?: User;
    }
  }
}

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const userId = getAuth(req).userId;
  if (!userId) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  req.userId = userId;
  void db
    .select({ accessStatus: usersTable.accessStatus })
    .from(usersTable)
    .where(eq(usersTable.clerkUserId, userId))
    .limit(1)
    .then(([user]) => {
      if (user?.accessStatus === "suspended") {
        res.status(403).json({ error: "Account access is suspended" });
        return;
      }
      next();
    })
    .catch(() => res.status(500).json({ error: "Unable to verify account access" }));
}

export async function getOrCreateLocalUser(req: Request): Promise<User> {
  const userId = req.userId ?? getAuth(req).userId;
  if (!userId) {
    throw new Error("Authentication required");
  }

  const existing = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.clerkUserId, userId))
    .limit(1);

  if (existing[0]) {
    req.localUser = existing[0];
    return existing[0];
  }

  const now = new Date();
  const trialEndsAt = new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000);

  try {
    const inserted = await db
      .insert(usersTable)
      .values({
        clerkUserId: userId,
        trialStartedAt: now,
        trialEndsAt,
      })
      .onConflictDoNothing({ target: usersTable.clerkUserId })
      .returning();

    if (inserted[0]) {
      req.localUser = inserted[0];
      return inserted[0];
    }
  } catch {
    // A concurrent first request can race the unique index. Read below.
  }

  const createdByAnotherRequest = await db
    .select()
    .from(usersTable)
    .where(and(eq(usersTable.clerkUserId, userId)))
    .limit(1);

  if (!createdByAnotherRequest[0]) {
    throw new Error("Unable to provision local account");
  }
  req.localUser = createdByAnotherRequest[0];
  return createdByAnotherRequest[0];
}