---
name: Admin access policy
description: Durable rules for protecting the MarketSim administrator area.
---

Admin access must be enforced by a server-side allowlist of Clerk user IDs, not by hiding a frontend route. Keep development and production allowlists separate because Replit-managed Clerk uses separate user environments.

**Why:** A frontend-only admin link can be discovered and Clerk development IDs do not reliably identify the same user in production.

**How to apply:** Use the ADMIN_CLERK_USER_IDS environment configuration in each environment, keep admin mutations behind the admin middleware, and require confirmation for access, session, and subscription changes.