import {
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export const usersTable = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    clerkUserId: text("clerk_user_id").notNull(),
    email: text("email"),
    displayName: text("display_name"),
    accessStatus: text("access_status").notNull().default("active"),
    suspendedAt: timestamp("suspended_at"),
    suspensionReason: text("suspension_reason"),
    trialStartedAt: timestamp("trial_started_at").notNull().defaultNow(),
    trialEndsAt: timestamp("trial_ends_at").notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (table) => ({
    clerkUserIdIdx: uniqueIndex("users_clerk_user_id_idx").on(table.clerkUserId),
  }),
);

export const subscriptionsTable = pgTable(
  "subscriptions",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    provider: text("provider").notNull().default("whop"),
    planId: text("plan_id").notNull(),
    membershipId: text("membership_id"),
    checkoutId: text("checkout_id"),
    status: text("status").notNull().default("pending"),
    currentPeriodEnd: timestamp("current_period_end"),
    cancelAtPeriodEnd: integer("cancel_at_period_end").notNull().default(0),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
    lastSyncedAt: timestamp("last_synced_at").notNull().defaultNow(),
  },
  (table) => ({
    membershipIdx: uniqueIndex("subscriptions_membership_id_idx").on(
      table.membershipId,
    ),
  }),
);

export const usageTable = pgTable(
  "usage",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    periodStart: timestamp("period_start").notNull(),
    simulationCount: integer("simulation_count").notNull().default(0),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (table) => ({
    userPeriodIdx: uniqueIndex("usage_user_period_idx").on(
      table.userId,
      table.periodStart,
    ),
  }),
);

export const checkoutSessionsTable = pgTable(
  "checkout_sessions",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    checkoutId: text("checkout_id").notNull(),
    planId: text("plan_id").notNull(),
    stateHash: text("state_hash").notNull(),
    status: text("status").notNull().default("created"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    completedAt: timestamp("completed_at"),
  },
  (table) => ({
    checkoutIdx: uniqueIndex("checkout_sessions_checkout_id_idx").on(
      table.checkoutId,
    ),
  }),
);

export const webhookEventsTable = pgTable(
  "webhook_events",
  {
    id: serial("id").primaryKey(),
    eventId: text("event_id").notNull(),
    eventType: text("event_type").notNull(),
    receivedAt: timestamp("received_at").notNull().defaultNow(),
    payload: text("payload"),
  },
  (table) => ({
    eventIdx: uniqueIndex("webhook_events_event_id_idx").on(table.eventId),
  }),
);

export type User = typeof usersTable.$inferSelect;
export type Subscription = typeof subscriptionsTable.$inferSelect;
export type Usage = typeof usageTable.$inferSelect;